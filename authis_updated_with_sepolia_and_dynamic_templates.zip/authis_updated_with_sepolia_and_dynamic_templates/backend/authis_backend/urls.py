from django.contrib import admin
from django.urls import path
from certificates import views as cert_views
from accounts import views as account_views

urlpatterns = [
    path("admin/", admin.site.urls),

    # Front page & auth
    path("", cert_views.home, name="home"),
    path("login/", account_views.login_view, name="login"),
    path("register/", account_views.register_view, name="register"),
    path("dashboard/", cert_views.dashboard, name="dashboard"),

    # Certificate flows
    path("certificates/issue/", cert_views.issue_certificate, name="issue_certificate"),
    path("certificates/verify/", cert_views.verify_certificate, name="verify_certificate"),
    path("certificates/list/", cert_views.list_certificates, name="list_certificates"),
    path("certificates/<int:pk>/", cert_views.certificate_detail, name="certificate_detail"),
]
