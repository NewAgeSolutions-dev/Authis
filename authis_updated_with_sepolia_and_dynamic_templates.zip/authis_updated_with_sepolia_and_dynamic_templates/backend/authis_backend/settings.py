import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = "replace-this-with-a-secure-key"
DEBUG = True
ALLOWED_HOSTS = ["*"]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "accounts",
    "certificates",
    "blockchain",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "authis_backend.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR.parent / "frontend"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "authis_backend.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "Africa/Harare"
USE_I18N = True
USE_TZ = True

STATIC_URL = "/static/"
STATICFILES_DIRS = [BASE_DIR.parent / "frontend"]

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# Blockchain integration settings (Sepolia testnet)
import json as _json

WEB3_PROVIDER = os.environ.get(
    "AUTHIS_WEB3_PROVIDER",
    "https://sepolia.infura.io/v3/YOUR_INFURA_PROJECT_ID",
)

CERT_CONTRACT_ADDRESS = os.environ.get("AUTHIS_CERT_CONTRACT_ADDRESS", "")
ISSUER_ADDRESS = os.environ.get("AUTHIS_ISSUER_ADDRESS", "")
ISSUER_PRIVATE_KEY = os.environ.get("AUTHIS_ISSUER_PRIVATE_KEY", "")

# ABI should be provided as a JSON string in the environment
CERT_CONTRACT_ABI = _json.loads(os.environ.get("AUTHIS_CERT_CONTRACT_ABI", "[]"))

FABRIC_GATEWAY_URL = os.environ.get("AUTHIS_FABRIC_GATEWAY_URL", "http://localhost:4000")

