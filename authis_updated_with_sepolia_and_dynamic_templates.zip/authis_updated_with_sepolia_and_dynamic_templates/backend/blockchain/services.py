import os
import json
import hashlib
from typing import Tuple

from django.conf import settings
from web3 import Web3


# --- Web3 / Sepolia setup ----------------------------------------------------

w3 = Web3(Web3.HTTPProvider(settings.WEB3_PROVIDER))
if not w3.is_connected():
    raise RuntimeError("Web3 is not connected. Check your WEB3_PROVIDER setting.")

CONTRACT_ADDRESS = Web3.to_checksum_address(settings.CERT_CONTRACT_ADDRESS)
CONTRACT_ABI = settings.CERT_CONTRACT_ABI

contract = w3.eth.contract(address=CONTRACT_ADDRESS, abi=CONTRACT_ABI)

ISSUER_ADDRESS = Web3.to_checksum_address(settings.ISSUER_ADDRESS)
ISSUER_PRIVATE_KEY = settings.ISSUER_PRIVATE_KEY


# --- Helpers -----------------------------------------------------------------


def compute_certificate_hash_string(
    certificate_id: str,
    student_name: str,
    student_id: str,
    programme: str,
    grade: str,
    date_issued: str,
    institution_name: str,
) -> str:
    """Canonical data string used for hashing and verification."""
    return "|".join(
        [
            certificate_id.strip(),
            student_name.strip(),
            (student_id or "").strip(),
            programme.strip(),
            (grade or "").strip(),
            date_issued.strip(),
            institution_name.strip(),
        ]
    )


def compute_sha256_hex(data_string: str) -> str:
    return hashlib.sha256(data_string.encode("utf-8")).hexdigest()


# --- Sepolia anchor & verify -------------------------------------------------


def anchor_certificate_on_evm(
    certificate_id: str,
    data_string: str,
) -> Tuple[str, str]:
    """Anchor certificate hash on Sepolia via the Authis contract.

    Returns (record_hash_hex, tx_hash_hex).
    """
    record_hash_hex = compute_sha256_hex(data_string)
    hash_bytes32 = bytes.fromhex(record_hash_hex)

    nonce = w3.eth.get_transaction_count(ISSUER_ADDRESS)
    gas_price = w3.eth.gas_price

    tx = contract.functions.storeCertificateHash(
        certificate_id,
        hash_bytes32,
    ).build_transaction(
        {
            "from": ISSUER_ADDRESS,
            "nonce": nonce,
            "gas": 300000,
            "gasPrice": gas_price,
        }
    )

    signed_tx = w3.eth.account.sign_transaction(tx, private_key=ISSUER_PRIVATE_KEY)
    tx_hash = w3.eth.send_raw_transaction(signed_tx.raw_transaction)
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash)

    if receipt.status != 1:
        raise RuntimeError("Sepolia transaction failed")

    return record_hash_hex, tx_hash.hex()


def verify_certificate_on_evm(
    certificate_id: str,
    data_string: str,
) -> bool:
    """Verify that the given certificate data matches the stored hash on Sepolia."""
    record_hash_hex = compute_sha256_hex(data_string)
    hash_bytes32 = bytes.fromhex(record_hash_hex)
    return contract.functions.verifyCertificateHash(
        certificate_id,
        hash_bytes32,
    ).call()
