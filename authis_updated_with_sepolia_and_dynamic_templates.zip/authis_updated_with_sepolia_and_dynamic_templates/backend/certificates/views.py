from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .models import Certificate
from blockchain.services import (
    anchor_certificate_on_evm,
    verify_certificate_on_evm,
    compute_certificate_hash_string,
)


def home(request):
    """Public landing page."""
    return render(request, "index.html")


@login_required
def dashboard(request):
    """Institution dashboard showing stats + recent certificates."""
    certs = Certificate.objects.filter(institution=request.user).order_by("-created_at")

    stats = {
        "total": certs.count(),
        "recent": certs[:5],
        "with_chain_hash": certs.exclude(evm_hash__isnull=True).exclude(evm_hash="").count(),
    }

    context = {
        "certificates": certs,
        "stats": stats,
    }
    return render(request, "dashboard.html", context)


@login_required
def issue_certificate(request):
    """
    Issue a certificate:
    - Save to DB
    - Anchor hash on Sepolia (EVM)
    """
    if request.method == "POST":
        certificate_id = request.POST.get("certificate_id", "").strip()
        student_name = request.POST.get("student_name", "").strip()
        student_id = request.POST.get("student_id", "").strip()
        programme = request.POST.get("programme", "").strip()
        grade = request.POST.get("grade", "").strip()
        date_issued = request.POST.get("date_issued", "").strip()  # YYYY-MM-DD string

        if not all([certificate_id, student_name, programme, date_issued]):
            messages.error(request, "Please fill in all required fields.")
            return render(request, "issue-certificate.html")

        cert = Certificate.objects.create(
            certificate_id=certificate_id,
            student_name=student_name,
            student_id=student_id,
            programme=programme,
            grade=grade,
            date_issued=date_issued,
            institution=request.user,
        )

        data_str = compute_certificate_hash_string(
            certificate_id=cert.certificate_id,
            student_name=cert.student_name,
            student_id=cert.student_id,
            programme=cert.programme,
            grade=cert.grade,
            date_issued=str(cert.date_issued),
            institution_name=request.user.username,
        )

        try:
            record_hash_hex, tx_hash = anchor_certificate_on_evm(
                certificate_id=cert.certificate_id,
                data_string=data_str,
            )
            cert.evm_hash = record_hash_hex
            cert.fabric_status = "Anchored on Sepolia"
            cert.save()

            messages.success(
                request,
                f"Certificate issued and anchored on Sepolia (tx: {tx_hash[:10]}...).",
            )
        except Exception as e:
            messages.warning(
                request,
                f"Certificate issued, but Sepolia anchoring failed: {e}",
            )

        return redirect("certificate_detail", pk=cert.pk)

    return render(request, "issue-certificate.html")


@login_required
def list_certificates(request):
    certs = Certificate.objects.filter(institution=request.user).order_by("-created_at")
    return render(request, "certificates.html", {"certificates": certs})


@login_required
def certificate_detail(request, pk):
    cert = get_object_or_404(Certificate, pk=pk, institution=request.user)

    local_hash = compute_certificate_hash_string(
        certificate_id=cert.certificate_id,
        student_name=cert.student_name,
        student_id=cert.student_id,
        programme=cert.programme,
        grade=cert.grade,
        date_issued=str(cert.date_issued),
        institution_name=request.user.username,
    )

    context = {
        "certificate": cert,
        "local_hash": local_hash,
    }
    return render(request, "certificate-detail.html", context)


def verify_certificate(request):
    """
    Public verification page:
    - Takes certificate_id, student_name, student_id
    - Looks up local DB
    - Verifies hash against Sepolia
    """
    context = {}
    if request.method == "POST":
        certificate_id = request.POST.get("certificate_id", "").strip()
        student_name = request.POST.get("student_name", "").strip()
        student_id = request.POST.get("student_id", "").strip()

        if not certificate_id:
            context["verified"] = False
            context["message"] = "Certificate ID is required."
            return render(request, "verify.html", context)

        try:
            cert = Certificate.objects.get(
                certificate_id=certificate_id,
                student_name__iexact=student_name or "",
                student_id__iexact=student_id or "",
            )
        except Certificate.DoesNotExist:
            context["verified"] = False
            context["message"] = "No matching certificate found in Authis records."
            return render(request, "verify.html", context)

        data_str = compute_certificate_hash_string(
            certificate_id=cert.certificate_id,
            student_name=cert.student_name,
            student_id=cert.student_id,
            programme=cert.programme,
            grade=cert.grade,
            date_issued=str(cert.date_issued),
            institution_name=cert.institution.username,
        )

        try:
            on_chain_ok = verify_certificate_on_evm(
                certificate_id=cert.certificate_id,
                data_string=data_str,
            )
            context["verified"] = on_chain_ok
            context["certificate"] = cert

            if on_chain_ok:
                context["message"] = "Certificate is valid and matches the blockchain record."
            else:
                context["message"] = (
                    "Certificate exists in Authis, but does NOT match the blockchain record."
                )
        except Exception as e:
            context["verified"] = False
            context["certificate"] = cert
            context["message"] = f"Error contacting blockchain: {e}"

    return render(request, "verify.html", context)
