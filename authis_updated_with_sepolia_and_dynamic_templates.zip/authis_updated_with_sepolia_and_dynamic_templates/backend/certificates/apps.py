from django.apps import AppConfig

class CertificatesConfig(AppConfig):
    name = "certificates"
