from django.db import models
from django.conf import settings

class Certificate(models.Model):
    certificate_id = models.CharField(max_length=64, unique=True)
    student_name = models.CharField(max_length=255)
    student_id = models.CharField(max_length=64, blank=True, null=True)
    programme = models.CharField(max_length=255)
    grade = models.CharField(max_length=50, blank=True, null=True)
    date_issued = models.DateField()
    institution = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="issued_certificates",
    )
    evm_hash = models.CharField(max_length=128, blank=True, null=True)
    fabric_status = models.CharField(max_length=255, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.certificate_id} - {self.student_name}"
