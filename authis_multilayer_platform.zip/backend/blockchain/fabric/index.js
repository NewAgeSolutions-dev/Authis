"use strict";

const { Contract } = require("fabric-contract-api");

class AuthisChaincode extends Contract {

    async issueCertificate(ctx, certId, certJson) {
        const exists = await this.certificateExists(ctx, certId);
        if (exists) {
            throw new Error(`Certificate ${certId} already exists`);
        }
        const cert = JSON.parse(certJson);
        cert.status = "ISSUED";
        cert.issuedAt = new Date().toISOString();

        await ctx.stub.putState(certId, Buffer.from(JSON.stringify(cert)));
        return JSON.stringify(cert);
    }

    async revokeCertificate(ctx, certId) {
        const certBytes = await ctx.stub.getState(certId);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }
        const cert = JSON.parse(certBytes.toString());
        cert.status = "REVOKED";
        cert.revokedAt = new Date().toISOString();

        await ctx.stub.putState(certId, Buffer.from(JSON.stringify(cert)));
        return JSON.stringify(cert);
    }

    async readCertificate(ctx, certId) {
        const certBytes = await ctx.stub.getState(certId);
        if (!certBytes || certBytes.length === 0) {
            throw new Error(`Certificate ${certId} does not exist`);
        }
        return certBytes.toString();
    }

    async certificateExists(ctx, certId) {
        const certBytes = await ctx.stub.getState(certId);
        return certBytes && certBytes.length > 0;
    }
}

module.exports = AuthisChaincode;
