import json
import hashlib
import requests
from django.conf import settings
from web3 import Web3

w3 = Web3(Web3.HTTPProvider(settings.WEB3_PROVIDER))

def hash_certificate(cert_data: dict) -> str:
    serialized = json.dumps(cert_data, sort_keys=True).encode("utf-8")
    return hashlib.sha256(serialized).hexdigest()

def issue_certificate_on_blockchains(cert_id: str, cert_data: dict):
    cert_hash_hex = hash_certificate(cert_data)

    # EVM / Solidity call (pseudo - requires real ABI and keys)
    try:
        contract = w3.eth.contract(
            address=settings.CERT_CONTRACT_ADDRESS,
            abi=settings.CERT_CONTRACT_ABI,
        )
        # NOTE: for production you must sign this transaction with a private key
        # Here we only show the intent.
        tx = contract.functions.issueCertificate(
            Web3.to_bytes(text=cert_id),
            Web3.to_bytes(hexstr=cert_hash_hex),
        )
        # In a real deployment, build, sign and send the transaction, then wait for receipt.
    except Exception as e:
        print("EVM issue error:", e)

    # Hyperledger Fabric call via REST gateway (example)
    fabric_status = None
    try:
        resp = requests.post(
            f"{settings.FABRIC_GATEWAY_URL}/certificates/issue",
            json={"certId": cert_id, "certData": cert_data},
            timeout=10,
        )
        if resp.ok:
            fabric_status = resp.json()
    except Exception as e:
        print("Fabric issue error:", e)

    return {"evm_hash": cert_hash_hex, "fabric_status": fabric_status}

def verify_certificate_on_blockchains(cert_id: str, cert_data: dict):
    cert_hash_hex = hash_certificate(cert_data)
    result = {
        "evm_valid": False,
        "evm_revoked": False,
        "evm_issuer": None,
        "evm_issued_at": None,
        "fabric_payload": None,
    }

    # EVM verify
    try:
        contract = w3.eth.contract(
            address=settings.CERT_CONTRACT_ADDRESS,
            abi=settings.CERT_CONTRACT_ABI,
        )
        valid, revoked, issuer, issued_at = contract.functions.verifyCertificate(
            Web3.to_bytes(text=cert_id),
            Web3.to_bytes(hexstr=cert_hash_hex),
        ).call()
        result.update(
            {
                "evm_valid": bool(valid),
                "evm_revoked": bool(revoked),
                "evm_issuer": issuer,
                "evm_issued_at": issued_at,
            }
        )
    except Exception as e:
        print("EVM verify error:", e)

    # Fabric read
    try:
        resp = requests.get(
            f"{settings.FABRIC_GATEWAY_URL}/certificates/{cert_id}",
            timeout=10,
        )
        if resp.ok:
            result["fabric_payload"] = resp.json()
    except Exception as e:
        print("Fabric verify error:", e)

    return result
