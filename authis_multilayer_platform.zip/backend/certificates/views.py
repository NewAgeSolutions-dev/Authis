from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Certificate
from blockchain.services import issue_certificate_on_blockchains, verify_certificate_on_blockchains

def home(request):
    return render(request, "index.html")

@login_required
def dashboard(request):
    certs = Certificate.objects.filter(institution=request.user).order_by("-created_at")
    return render(request, "dashboard.html", {"certificates": certs})

@login_required
def issue_certificate(request):
    if request.method == "POST":
        cert_id = request.POST.get("certificate_id")
        student_name = request.POST.get("student_name")
        student_id = request.POST.get("student_id")
        programme = request.POST.get("programme")
        grade = request.POST.get("grade")
        date_issued = request.POST.get("date_issued") or timezone.now().date()

        cert_data = {
            "certificate_id": cert_id,
            "student_name": student_name,
            "student_id": student_id,
            "programme": programme,
            "grade": grade,
            "date_issued": str(date_issued),
            "institution": request.user.institution_name or request.user.username,
        }

        result = issue_certificate_on_blockchains(cert_id, cert_data)

        cert = Certificate.objects.create(
            certificate_id=cert_id,
            student_name=student_name,
            student_id=student_id,
            programme=programme,
            grade=grade,
            date_issued=date_issued,
            institution=request.user,
            evm_hash=result.get("evm_hash"),
            fabric_status=result.get("fabric_status"),
        )

        return redirect("dashboard")

    return render(request, "issue-certificate.html")

def list_certificates(request):
    certs = Certificate.objects.all().order_by("-created_at")
    return render(request, "certificates.html", {"certificates": certs})

def verify_certificate(request):
    if request.method == "POST":
        cert_id = request.POST.get("certificate_id")
        student_name = request.POST.get("student_name")
        student_id = request.POST.get("student_id")

        cert_data = {
            "certificate_id": cert_id,
            "student_name": student_name,
            "student_id": student_id,
        }

        verification = verify_certificate_on_blockchains(cert_id, cert_data)
        context = {
            "cert_id": cert_id,
            "student_name": student_name,
            "student_id": student_id,
            "verification": verification,
        }
        return render(request, "verify-result.html", context)

    return render(request, "verify.html")
