# Authis Multi-Layer Platform (Django + Solidity + Hyperledger)

This folder contains:
- `/frontend`  → your original Authis HTML/CSS (lightly wired for Django templates)
- `/backend`   → Django project + apps for accounts, certificates, blockchain integration
- `/backend/blockchain/solidity/AuthisCertificateRegistry.sol` → EVM anchor contract
- `/backend/blockchain/fabric/index.js` → Hyperledger Fabric chaincode skeleton

## High-level flow

1. Institution logs in and issues a certificate via `issue-certificate.html`.
2. Django saves certificate in the relational DB and calls:
   - Solidity contract to anchor the hash on an EVM chain.
   - Fabric chaincode (through a REST gateway) to store rich certificate state.
3. Verifier uses `verify.html`, Django recomputes the hash and:
   - Calls the Solidity `verifyCertificate` view function.
   - Reads the Fabric record.
   - Returns a combined verification result shown on `verify-result.html`.

You still need to:
- Install Django and dependencies.
- Configure `AUTH_USER_MODEL` to use `AuthisUser`.
- Provide real WEB3 provider, contract address + ABI, and Fabric gateway URLs.
- Deploy the Solidity contract and Fabric chaincode in your chosen environments.
